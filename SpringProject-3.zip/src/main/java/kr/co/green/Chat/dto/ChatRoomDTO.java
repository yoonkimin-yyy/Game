package kr.co.green.Chat.dto;



public class ChatRoomDTO {

	
	private String roomId;
	
	private String roomName;
}
