package kr.co.green.mypage.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MyPageMapper {

}
