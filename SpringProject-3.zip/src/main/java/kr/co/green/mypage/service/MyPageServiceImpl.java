package kr.co.green.mypage.service;

import org.springframework.stereotype.Service;

@Service
public class MyPageServiceImpl implements MyPageService{

	
	@Override
	public String getUserEmail() {
		
		
		
		return null;
	}
	
	
	
	
}
