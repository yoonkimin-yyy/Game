package kr.co.green.mypage.util;

import org.springframework.stereotype.Component;

@Component
public class PagiNation {

}
