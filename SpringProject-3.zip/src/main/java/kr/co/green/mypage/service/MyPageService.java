package kr.co.green.mypage.service;

public interface MyPageService {

	
	public String getUserEmail();
}
