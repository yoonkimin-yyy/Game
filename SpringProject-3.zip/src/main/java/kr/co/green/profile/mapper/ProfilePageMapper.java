package kr.co.green.profile.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ProfilePageMapper {

	
}
