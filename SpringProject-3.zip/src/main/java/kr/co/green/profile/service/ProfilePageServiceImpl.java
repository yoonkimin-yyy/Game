package kr.co.green.profile.service;

import org.springframework.stereotype.Service;

import kr.co.green.mypage.service.MyPageService;
@Service
public class ProfilePageServiceImpl implements MyPageService {
	

	@Override
	public String getUserEmail() {
		
		
		
		return null;
	}
}
