package kr.co.green.profile.service;



public interface ProfilePageService {

	public String getUserEmail();
	
}
