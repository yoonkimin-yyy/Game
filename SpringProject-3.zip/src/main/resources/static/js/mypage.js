const change1 = document.getElementById("card1");
const change2 = document.getElementById("card2");
const change11 = document.getElementById("card1-1");
const change3 = document.getElementById("card3");
const change4 = document.getElementById("card4");
const change5 = document.getElementById("card5");
const change6 = document.getElementById("card6");
const change7 = document.getElementById("card7");

function clickFnc1(){

    if(true){
        change1.style.display = "block";
        change2.style.display = "block";
        change11.style.display = "none";
        change3.style.display = "none";
        change4.style.display = "none";
        change5.style.display = "none";
        change6.style.display = "none";
        change7.style.display = "none";
        
    }
}

function clickFnc2(){

    

    if(true){
        change3.style.display = "block";
        change4.style.display = "block";
        change1.style.display = "none";
        change2.style.display = "none";
        change11.style.display = "none";
        change5.style.display = "none";
        change6.style.display = "none";
        change7.style.display = "none";
    }
}

function clickFnc3(){


    if(true){
        change5.style.display = "block";
        change6.style.display = "block";
        change1.style.display = "none";
        change2.style.display = "none";
        change11.style.display = "none";
        change3.style.display = "none";
        change4.style.display = "none";
        change7.style.display = "none";
    }
}

function clickFnc4(){


    if(true){
        change7.style.display = "block";
        change1.style.display = "none";
        change2.style.display = "none";
        change11.style.display = "none";
        change3.style.display = "none";
        change4.style.display = "none";
        change5.style.display = "none";
        change6.style.display = "none";
    }
}
function clickFnc5(){
    if(true){
        change11.style.display = "block";
        change1.style.display = "none";
        change2.style.display = "none";
        change7.style.display = "none";
        change3.style.display = "none";
        change4.style.display = "none";
        change5.style.display = "none";
        change6.style.display = "none";
    }
}


